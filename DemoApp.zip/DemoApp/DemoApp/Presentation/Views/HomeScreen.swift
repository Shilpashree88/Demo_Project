//
//  HomeScreen.swift
//  DemoApp
//
//  Created by M C, Shilpashree on 19/01/25.
//

import SwiftUI

struct HomeScreen: View {
    @ObservedObject var viewModel: HomeViewModel
    var body: some View {
        NavigationView {
            List(viewModel.companies) { company in
                NavigationLink(destination: CompanyDetailsScreen(viewModel: CompanyDetailsViewModel(productsUseCase: ProductInfo(ProductsDetails: ProductsDetailsTransaction(service: NetworkService(transcaction: APITransaction())))))) {
                    VStack(alignment: .leading) {
                        Text(company.name)
                            .font(.headline)
                    }
                }
            }
            .onAppear {
                viewModel.fetchCompanies()
            }
            .navigationTitle("List")
        }
    }
    
}
#Preview {
    HomeScreen(viewModel: HomeViewModel(productsUseCase: ProductInfo(ProductsDetails: ProductsDetailsTransaction(service: NetworkService(transcaction: APITransaction())))))
}

