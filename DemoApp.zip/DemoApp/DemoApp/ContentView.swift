//
//  ContentView.swift
//  DemoApp
//
//  Created by M C, Shilpashree on 19/01/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HomeScreen(viewModel: HomeViewModel(productsUseCase: ProductInfo(ProductsDetails: ProductsDetailsTransaction(service: NetworkService(transcaction: APITransaction())))))
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
